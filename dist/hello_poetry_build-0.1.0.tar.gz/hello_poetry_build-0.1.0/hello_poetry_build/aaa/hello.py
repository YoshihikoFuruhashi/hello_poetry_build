def add(value: int):
    return value + 10
